# Upgrade Plan: Enterprise Digital Payment Platform (20260324085847)

- **Generated**: 2026-03-24 08:58:47 UTC
- **HEAD Branch**: main
- **HEAD Commit ID**: [Will update after branch checkout]

## Available Tools

| Tool | Version | Status | Path | Notes |
|------|---------|--------|------|-------|
| Maven | 3.9.14 | ✅ Available | C:\ProgramData\chocolatey\lib\maven\apache-maven-3.9.14 | Compatible with Java 21 and Spring Boot 3.5 |
| Java 17 | 17.0.6, 17.0.9 | ✅ Installed | C:\Program Files\Eclipse Adoptium\jdk-17.0.6.10-hotspot | Current version |
| Java 21 | 21.0.8 | ✅ Installed | C:\Users\lbanjoko\.jdk\jdk-21.0.8 | Target version (installed for upgrade) |
| Maven Wrapper | Present | ✅ Available | In all modules (.mvn/) | Supports Java 21 |

## Guidelines

- Maintain backward compatibility where possible
- Verify all 8 microservices build and test successfully
- Check Spring Cloud compatibility with new Spring Boot version
- Validate dependency upgrades (databases, message queues, etc.)
- Leverage OpenRewrite automation where helpful to reduce manual changes

## Options

- Working branch: appmod/java-upgrade-20260324085847
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java from 17 to 21 LTS
- Upgrade Spring Boot from 3.1.5 to 3.5.x (latest stable in 3.5 line)
- Upgrade Spring Cloud from 2023.0.0 to 2024.0.x (aligned with Spring Boot 3.5)

## Upgrade Goals

<!--
  List ONLY the explicitly user-requested target versions.
  These are the primary goals that drive all other upgrade decisions.

  SAMPLE:
  - Upgrade Java from 8 to 21
  - Upgrade Spring Boot from 2.5.x to 3.2.x
-->

### Technology Stack

<!--
  Table of core dependencies and their compatibility with upgrade goals.
  IMPORTANT: Analyze ALL modules in multi-module projects, not just the root module.
  Only include: direct dependencies + those critical for upgrade compatibility.
  CRITICAL: Identify and clearly flag EOL (End of Life) dependencies - these pose security risks and must be upgraded.

  Columns:
  - Technology/Dependency: Name of the dependency (mark EOL dependencies with "⚠️ EOL" suffix)
  - Current: Version currently in use
  - Min Compatible Version: Minimum version that works with upgrade goals (or N/A if replaced)
  - Why Incompatible: Explanation of incompatibility, or "-" if already compatible. For EOL deps, mention security/support concerns.

  IMPORTANT: Include build tools (Maven/Gradle), wrappers, and key build plugins in this table.
  Build tools and plugins are upgrade-critical even though they are not runtime dependencies.

  SAMPLE:
  | Technology/Dependency    | Current | Min Compatible | Why Incompatible                               |
  | ------------------------ | ------- | -------------- | ---------------------------------------------- |
  | Java                     | 8       | 21             | User requested                                 |
  | Spring Boot              | 2.5.0   | 3.2.0          | User requested                                 |
  | Spring Framework         | 5.3.x   | 6.1.x          | Spring Boot 3.2 requires Spring Framework 6.1+ |
  | Maven (wrapper)          | 3.6.3   | 3.9.0          | Maven 3.6.x does not support Java 21           |
  | maven-compiler-plugin    | 3.8.1   | 3.11.0         | Older versions cannot compile Java 21 bytecode |
  | maven-surefire-plugin    | 2.22.2  | 3.1.0          | Older versions may fail with Java 17+ module system |
  | Hibernate                | 5.4.x   | 6.1.x          | Spring Boot 3.x requires Hibernate 6+          |
  | javax.servlet ⚠️ EOL     | 4.0     | N/A            | Replaced by jakarta.servlet in Spring Boot 3.x; javax namespace EOL |
  | Log4j ⚠️ EOL             | 1.2.17  | N/A            | EOL since 2015, critical security vulnerabilities; replace with Logback/Log4j2 |
  | DWR ⚠️ EOL             | 3.0.1.rc  | N/A            | EOL since 2017, no longer maintained; consider replacing with modern alternatives |
  | Lombok                   | 1.18.20 | 1.18.20        | -                                              |
-->

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| --------------------- | ------- | -------------- | ---------------- |

### Derived Upgrades

<!--
  Required upgrades inferred from user targets based on compatibility rules.
  Each derived upgrade must have a justification explaining WHY it's required.
  Common derivations:
  - Spring Boot 3.x → Java 17+, Jakarta EE 9+, Hibernate 6.x, Spring Framework 6.x
  - Spring Boot 3.2+ → Spring Framework 6.1+
  - Spring Boot 4.x → Java 17+, Jakarta EE 10+, Spring Framework 7.x
  - Java 21 → Maven 3.9+, Gradle 8.5+, maven-compiler-plugin 3.11+
  - Java 25 → Maven 4.0+, Gradle 9.1+
  - Build tool upgrade → update wrapper version in `.mvn/wrapper/maven-wrapper.properties` or `gradle/wrapper/gradle-wrapper.properties`

  NOTE: LLM training data may be outdated. If a target version is not recognized,
  verify it from the web before making derivation decisions.

  SAMPLE:
  - Upgrade Spring Framework from 5.3.x to 6.1.x (Spring Boot 3.2 requires Spring 6.1)
  - Upgrade Hibernate from 5.4.x to 6.1.x (Spring Boot 3.x requires Hibernate 6)
  - Migrate from javax.* to jakarta.* (Spring Boot 3.x uses jakarta.*)
  - Upgrade Maven from 3.6.3 to 3.9.6 (Maven 3.6.x does not support Java 21 compilation); update wrapper version
  - Upgrade maven-compiler-plugin from 3.8.1 to 3.11.0 (required for Java 21 target/source)
-->

## Upgrade Steps

<!--
  Step-by-step upgrade plan. Each step should follow this format:
  - **Step N: <Descriptive Title>**
    - **Rationale**: Why this step is needed and why at this position
    - **Changes to Make**: ≤5 bullet points (concise)
    - **Verification**: Command, JDK, Expected Result

  VERIFICATION EXPECTATIONS:
  - Steps 1-N (Setup and Upgrade steps): Focus on COMPILATION SUCCESS. Tests may fail during intermediate steps.
  - Final step: COMPILATION SUCCESS + TEST PASS (if tests enabled in Options) through iterative fix loop.

  MANDATORY FIRST STEPS:
  The first two steps MUST always be:
  1. Setup Environment (install missing JDKs/build tools)
  2. Setup Baseline (establish pre-upgrade compile/test results)

  MANDATORY SETUP ENVIRONMENT STEP SAMPLE:

  - Step 1: Setup Environment
    - **Rationale**: Install required JDKs and build tools identified as missing in "Available Tools" section.
    - **Changes to Make**:
      - [ ] Install JDK 17 (required for Spring Boot 3.x compilation)
      - [ ] Install JDK 21 (target version for final validation)
      - [ ] Verify Maven Wrapper is executable
    - **Verification**:
      - Command: `#list_jdks` to confirm installations
      - Expected: All required JDKs available at specified paths

  ---

  MANDATORY SETUP BASELINE STEP SAMPLE:

  - Step 2: Setup Baseline
    - **Rationale**: Establish pre-upgrade compile and test results to measure upgrade success against.
    - **Changes to Make**:
      - [ ] Run baseline compilation with current JDK
      - [ ] Run baseline tests with current JDK
    - **Verification**:
      - Command: `mvn clean compile test-compile -q && mvn clean test -q` // run both compile and test
      - JDK: <current project JDK path>
      - Expected: Document SUCCESS/FAILURE, test pass rate (forms acceptance criteria)

  ---

  SAMPLE STEP (framework upgrade):

  - Step N: Upgrade to Spring Boot 3.2
    - **Rationale**: Core framework upgrade. Hibernate and other deps will auto-upgrade via Spring Boot BOM.
    - **Prerequisites**: <only if JDK 17 not available>
      - `#install_jdk version=17`
    - **Changes to Make**:
      - [ ] Update spring-boot-starter-parent to 3.2.x
      - [ ] Update Spring Framework to 6.1.x (if explicitly declared)
      - [ ] Run jakarta namespace migration (javax.* → jakarta.*)
      - [ ] Fix compilation errors
    - **Verification**:
      - Command: `mvn clean test-compile -q` // compile only
      - JDK: <JDK 17 path>
      - Expected: Compilation SUCCESS (tests may fail - will be fixed in Final Validation)

  ---

  MANDATORY FINAL STEP (must always be the last step):

  - Step N: Final Validation
    - **Rationale**: Verify all upgrade goals met, project compiles successfully, all tests pass (if tests enabled in Options).
    - **Prerequisites**: <only if target JDK not available>
      - `#install_jdk version=21` (if upgrading to Java 21)
    - **Changes to Make**:
      - [ ] Verify all target versions in pom.xml/build.gradle
      - [ ] Resolve ALL TODOs and temporary workarounds from previous steps
      - [ ] Clean rebuild with target JDK
      - [ ] Fix any remaining compilation errors
      - [ ] Run full test suite and fix ALL test failures (iterative fix loop until 100% pass) — **skip if "Run tests before and after the upgrade: false" in Options**
    - **Verification**:
      - Command: `mvn clean test -q` (if tests enabled) or `mvn clean test-compile -q` (if tests disabled)
      - JDK: <target JDK path>
      - Expected: Compilation SUCCESS + 100% tests pass (if tests enabled)
-->

## Key Challenges

<!--
  Document high-risk areas that require special attention during upgrade.
  Each challenge should have a mitigation strategy. Be concise.
  Common challenges:
  - Breaking API changes (javax→jakarta)
  - EOL library replacements
  - Complex multi-dependency coordination
  - Custom framework extensions that may break

  SAMPLE:
  - **Jakarta EE Namespace Migration**
     - **Challenge**: Entire codebase uses javax.* packages (servlet, persistence, validation, inject, mail) that must migrate to jakarta.* in Spring Boot 3+.
     - **Strategy**: Use OpenRewrite's automated migration recipes after reaching Spring Boot 2.7.x to handle bulk namespace changes. Spring Boot 2.7.x provides javax-to-jakarta bridge making it ideal intermediate target.
  - **Hibernate 4.3 to 6.x Major Version Jump**
     - **Challenge**: Breaking changes in Hibernate 6 including removed APIs, behavior changes, and updated query syntax.
     - **Strategy**: Upgrade incrementally: Hibernate 5.6.x with Spring Boot 2.7.x, validate, then Hibernate 6.x with Spring Boot 3.2.x. Update jackson-datatype-hibernate4 → hibernate6 module. Expect schema validation and query adjustments.
-->
