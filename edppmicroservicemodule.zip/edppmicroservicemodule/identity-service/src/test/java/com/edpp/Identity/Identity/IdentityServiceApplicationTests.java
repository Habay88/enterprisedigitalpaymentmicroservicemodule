package com.edpp.Identity.Identity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdentityServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
